"use client";

import { useState, useEffect } from "react";
import { createClient } from "@/lib/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ChevronLeft, ChevronRight, CalendarDays } from "lucide-react";
import {
  format,
  startOfMonth,
  endOfMonth,
  eachDayOfInterval,
  isSameMonth,
  isSameDay,
  addMonths,
  subMonths,
  startOfWeek,
  endOfWeek,
  isToday,
} from "date-fns";
import type { Assignment, Class } from "@/lib/types";

type AssignmentWithClass = Assignment & { classes: Class };

export default function CalendarPage() {
  const [currentMonth, setCurrentMonth] = useState(new Date());
  const [assignments, setAssignments] = useState<AssignmentWithClass[]>([]);
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);
  const [loading, setLoading] = useState(true);

  const supabase = createClient();

  useEffect(() => {
    fetchAssignments();
  }, []);

  async function fetchAssignments() {
    const { data, error } = await supabase
      .from("assignments")
      .select("*, classes(*)")
      .order("due_date", { ascending: true });

    if (!error && data) {
      setAssignments(data as AssignmentWithClass[]);
    }
    setLoading(false);
  }

  const monthStart = startOfMonth(currentMonth);
  const monthEnd = endOfMonth(currentMonth);
  const calendarStart = startOfWeek(monthStart);
  const calendarEnd = endOfWeek(monthEnd);

  const calendarDays = eachDayOfInterval({
    start: calendarStart,
    end: calendarEnd,
  });

  function getAssignmentsForDay(date: Date) {
    return assignments.filter((a) => isSameDay(new Date(a.due_date), date));
  }

  function goToPreviousMonth() {
    setCurrentMonth(subMonths(currentMonth, 1));
  }

  function goToNextMonth() {
    setCurrentMonth(addMonths(currentMonth, 1));
  }

  function goToToday() {
    setCurrentMonth(new Date());
    setSelectedDate(new Date());
  }

  const selectedDateAssignments = selectedDate
    ? getAssignmentsForDay(selectedDate)
    : [];

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-foreground">Calendar</h1>
        <p className="text-muted-foreground mt-1">
          View your assignments and deadlines
        </p>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader className="pb-4">
            <div className="flex items-center justify-between">
              <CardTitle className="text-xl">
                {format(currentMonth, "MMMM yyyy")}
              </CardTitle>
              <div className="flex items-center gap-2">
                <Button variant="outline" size="sm" onClick={goToToday}>
                  Today
                </Button>
                <Button variant="outline" size="icon" onClick={goToPreviousMonth}>
                  <ChevronLeft className="h-4 w-4" />
                  <span className="sr-only">Previous month</span>
                </Button>
                <Button variant="outline" size="icon" onClick={goToNextMonth}>
                  <ChevronRight className="h-4 w-4" />
                  <span className="sr-only">Next month</span>
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-7 gap-px bg-border rounded-lg overflow-hidden">
              {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((day) => (
                <div
                  key={day}
                  className="bg-muted p-2 text-center text-sm font-medium text-muted-foreground"
                >
                  {day}
                </div>
              ))}
              {calendarDays.map((day) => {
                const dayAssignments = getAssignmentsForDay(day);
                const isCurrentMonth = isSameMonth(day, currentMonth);
                const isSelected = selectedDate && isSameDay(day, selectedDate);
                const isTodayDate = isToday(day);

                return (
                  <button
                    key={day.toISOString()}
                    onClick={() => setSelectedDate(day)}
                    className={`bg-card p-2 min-h-[80px] text-left transition-colors hover:bg-accent/50 ${
                      !isCurrentMonth ? "opacity-40" : ""
                    } ${isSelected ? "bg-accent ring-2 ring-primary ring-inset" : ""}`}
                  >
                    <span
                      className={`inline-flex items-center justify-center w-7 h-7 text-sm font-medium rounded-full ${
                        isTodayDate
                          ? "bg-primary text-primary-foreground"
                          : "text-foreground"
                      }`}
                    >
                      {format(day, "d")}
                    </span>
                    <div className="mt-1 space-y-1">
                      {dayAssignments.slice(0, 2).map((assignment) => (
                        <div
                          key={assignment.id}
                          className="flex items-center gap-1 text-xs truncate"
                        >
                          <div
                            className="w-2 h-2 rounded-full flex-shrink-0"
                            style={{ backgroundColor: assignment.classes.color }}
                          />
                          <span
                            className={`truncate ${
                              assignment.completed
                                ? "line-through text-muted-foreground"
                                : "text-foreground"
                            }`}
                          >
                            {assignment.title}
                          </span>
                        </div>
                      ))}
                      {dayAssignments.length > 2 && (
                        <span className="text-xs text-muted-foreground">
                          +{dayAssignments.length - 2} more
                        </span>
                      )}
                    </div>
                  </button>
                );
              })}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <CalendarDays className="h-5 w-5" />
              {selectedDate
                ? format(selectedDate, "EEEE, MMMM d")
                : "Select a date"}
            </CardTitle>
          </CardHeader>
          <CardContent>
            {!selectedDate ? (
              <p className="text-muted-foreground text-sm">
                Click on a date to see assignments
              </p>
            ) : selectedDateAssignments.length === 0 ? (
              <p className="text-muted-foreground text-sm">
                No assignments due on this date
              </p>
            ) : (
              <div className="space-y-3">
                {selectedDateAssignments.map((assignment) => (
                  <div
                    key={assignment.id}
                    className="flex items-start gap-3 p-3 rounded-lg bg-muted/50"
                  >
                    <div
                      className="w-3 h-3 rounded-full mt-1 flex-shrink-0"
                      style={{ backgroundColor: assignment.classes.color }}
                    />
                    <div className="flex-1 min-w-0">
                      <p
                        className={`font-medium ${
                          assignment.completed
                            ? "line-through text-muted-foreground"
                            : "text-foreground"
                        }`}
                      >
                        {assignment.title}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        {assignment.classes.name}
                      </p>
                      <p className="text-xs text-muted-foreground mt-1">
                        Due at {format(new Date(assignment.due_date), "h:mm a")}
                      </p>
                      {assignment.description && (
                        <p className="text-sm text-muted-foreground mt-2">
                          {assignment.description}
                        </p>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
