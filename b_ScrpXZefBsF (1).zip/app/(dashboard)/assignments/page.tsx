"use client";

import { useState, useEffect } from "react";
import { createClient } from "@/lib/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Plus, ClipboardList, Trash2 } from "lucide-react";
import { format } from "date-fns";
import type { Assignment, Class } from "@/lib/types";

type AssignmentWithClass = Assignment & { classes: Class };

export default function AssignmentsPage() {
  const [assignments, setAssignments] = useState<AssignmentWithClass[]>([]);
  const [classes, setClasses] = useState<Class[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const [newAssignment, setNewAssignment] = useState({
    title: "",
    description: "",
    class_id: "",
    due_date: "",
  });

  const supabase = createClient();

  useEffect(() => {
    fetchData();
  }, []);

  async function fetchData() {
    const [assignmentsRes, classesRes] = await Promise.all([
      supabase
        .from("assignments")
        .select("*, classes(*)")
        .order("due_date", { ascending: true }),
      supabase.from("classes").select("*").order("name"),
    ]);

    if (!assignmentsRes.error && assignmentsRes.data) {
      setAssignments(assignmentsRes.data as AssignmentWithClass[]);
    }
    if (!classesRes.error && classesRes.data) {
      setClasses(classesRes.data);
    }
    setLoading(false);
  }

  async function handleAddAssignment(e: React.FormEvent) {
    e.preventDefault();
    if (!newAssignment.title.trim() || !newAssignment.class_id || !newAssignment.due_date) return;

    setSubmitting(true);

    const {
      data: { user },
    } = await supabase.auth.getUser();

    if (!user) {
      setSubmitting(false);
      return;
    }

    const { data, error } = await supabase
      .from("assignments")
      .insert({
        title: newAssignment.title.trim(),
        description: newAssignment.description.trim() || null,
        class_id: newAssignment.class_id,
        due_date: new Date(newAssignment.due_date).toISOString(),
        user_id: user.id,
      })
      .select("*, classes(*)")
      .single();

    if (!error && data) {
      setAssignments([...assignments, data as AssignmentWithClass].sort(
        (a, b) => new Date(a.due_date).getTime() - new Date(b.due_date).getTime()
      ));
      setNewAssignment({ title: "", description: "", class_id: "", due_date: "" });
      setDialogOpen(false);
    }

    setSubmitting(false);
  }

  async function handleToggleComplete(assignmentId: string, completed: boolean) {
    const { error } = await supabase
      .from("assignments")
      .update({ completed })
      .eq("id", assignmentId);

    if (!error) {
      setAssignments(
        assignments.map((a) =>
          a.id === assignmentId ? { ...a, completed } : a
        )
      );
    }
  }

  async function handleDeleteAssignment(assignmentId: string) {
    const { error } = await supabase
      .from("assignments")
      .delete()
      .eq("id", assignmentId);

    if (!error) {
      setAssignments(assignments.filter((a) => a.id !== assignmentId));
    }
  }

  function getStatusColor(dueDate: string, completed: boolean) {
    if (completed) return "text-muted-foreground";
    const now = new Date();
    const due = new Date(dueDate);
    const diffDays = Math.ceil((due.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
    
    if (diffDays < 0) return "text-destructive";
    if (diffDays <= 2) return "text-amber-600";
    return "text-foreground";
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  const pendingAssignments = assignments.filter((a) => !a.completed);
  const completedAssignments = assignments.filter((a) => a.completed);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Assignments</h1>
          <p className="text-muted-foreground mt-1">
            Track and manage all your assignments
          </p>
        </div>
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button disabled={classes.length === 0}>
              <Plus className="h-4 w-4 mr-2" />
              Add Assignment
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Add New Assignment</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleAddAssignment} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="title">Title</Label>
                <Input
                  id="title"
                  placeholder="e.g., Chapter 5 Reading"
                  value={newAssignment.title}
                  onChange={(e) =>
                    setNewAssignment({ ...newAssignment, title: e.target.value })
                  }
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="class">Class</Label>
                <Select
                  value={newAssignment.class_id}
                  onValueChange={(value) =>
                    setNewAssignment({ ...newAssignment, class_id: value })
                  }
                  required
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select a class" />
                  </SelectTrigger>
                  <SelectContent>
                    {classes.map((c) => (
                      <SelectItem key={c.id} value={c.id}>
                        <div className="flex items-center gap-2">
                          <div
                            className="w-3 h-3 rounded-full"
                            style={{ backgroundColor: c.color }}
                          />
                          {c.name}
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="dueDate">Due Date</Label>
                <Input
                  id="dueDate"
                  type="datetime-local"
                  value={newAssignment.due_date}
                  onChange={(e) =>
                    setNewAssignment({ ...newAssignment, due_date: e.target.value })
                  }
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="description">Description (Optional)</Label>
                <Textarea
                  id="description"
                  placeholder="Add any notes or details..."
                  value={newAssignment.description}
                  onChange={(e) =>
                    setNewAssignment({ ...newAssignment, description: e.target.value })
                  }
                  rows={3}
                />
              </div>
              <Button type="submit" className="w-full" disabled={submitting}>
                {submitting ? "Adding..." : "Add Assignment"}
              </Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {classes.length === 0 ? (
        <Card className="border-dashed">
          <CardContent className="flex flex-col items-center justify-center py-12">
            <ClipboardList className="h-12 w-12 text-muted-foreground mb-4" />
            <h3 className="text-lg font-semibold text-foreground mb-1">
              Add a class first
            </h3>
            <p className="text-muted-foreground text-center">
              You need to create at least one class before adding assignments
            </p>
          </CardContent>
        </Card>
      ) : assignments.length === 0 ? (
        <Card className="border-dashed">
          <CardContent className="flex flex-col items-center justify-center py-12">
            <ClipboardList className="h-12 w-12 text-muted-foreground mb-4" />
            <h3 className="text-lg font-semibold text-foreground mb-1">
              No assignments yet
            </h3>
            <p className="text-muted-foreground text-center mb-4">
              Add your first assignment to start tracking your work
            </p>
            <Button onClick={() => setDialogOpen(true)}>
              <Plus className="h-4 w-4 mr-2" />
              Add Your First Assignment
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-8">
          {pendingAssignments.length > 0 && (
            <div className="space-y-3">
              <h2 className="text-lg font-semibold text-foreground">
                Pending ({pendingAssignments.length})
              </h2>
              <div className="space-y-2">
                {pendingAssignments.map((assignment) => (
                  <Card key={assignment.id} className="group">
                    <CardContent className="flex items-center gap-4 py-4">
                      <Checkbox
                        checked={assignment.completed}
                        onCheckedChange={(checked) =>
                          handleToggleComplete(assignment.id, checked as boolean)
                        }
                      />
                      <div
                        className="w-3 h-3 rounded-full flex-shrink-0"
                        style={{ backgroundColor: assignment.classes.color }}
                      />
                      <div className="flex-1 min-w-0">
                        <p className="font-medium text-foreground truncate">
                          {assignment.title}
                        </p>
                        <p className="text-sm text-muted-foreground">
                          {assignment.classes.name}
                        </p>
                      </div>
                      <div className="flex items-center gap-2">
                        <span
                          className={`text-sm font-medium ${getStatusColor(
                            assignment.due_date,
                            assignment.completed
                          )}`}
                        >
                          {format(new Date(assignment.due_date), "MMM d, h:mm a")}
                        </span>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="opacity-0 group-hover:opacity-100 transition-opacity text-destructive hover:text-destructive hover:bg-destructive/10"
                          onClick={() => handleDeleteAssignment(assignment.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                          <span className="sr-only">Delete assignment</span>
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          )}

          {completedAssignments.length > 0 && (
            <div className="space-y-3">
              <h2 className="text-lg font-semibold text-muted-foreground">
                Completed ({completedAssignments.length})
              </h2>
              <div className="space-y-2">
                {completedAssignments.map((assignment) => (
                  <Card key={assignment.id} className="group opacity-60">
                    <CardContent className="flex items-center gap-4 py-4">
                      <Checkbox
                        checked={assignment.completed}
                        onCheckedChange={(checked) =>
                          handleToggleComplete(assignment.id, checked as boolean)
                        }
                      />
                      <div
                        className="w-3 h-3 rounded-full flex-shrink-0"
                        style={{ backgroundColor: assignment.classes.color }}
                      />
                      <div className="flex-1 min-w-0">
                        <p className="font-medium text-foreground truncate line-through">
                          {assignment.title}
                        </p>
                        <p className="text-sm text-muted-foreground">
                          {assignment.classes.name}
                        </p>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-sm text-muted-foreground">
                          {format(new Date(assignment.due_date), "MMM d")}
                        </span>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="opacity-0 group-hover:opacity-100 transition-opacity text-destructive hover:text-destructive hover:bg-destructive/10"
                          onClick={() => handleDeleteAssignment(assignment.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                          <span className="sr-only">Delete assignment</span>
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
